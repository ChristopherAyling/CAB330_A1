# CAB330_A1
CAB330 Assignment 1

Requirements:

- Anaconda
- pandas
- numpy
- matplotlib
- scikit-learn
- seaborn
- graphviz (`conda install graphviz` then `conda install python-graphviz` [to get on path](https://stackoverflow.com/a/47043173/3421994))
- pydot  (https://stackoverflow.com/questions/28312534/graphvizs-executables-are-not-found-python-3-4)